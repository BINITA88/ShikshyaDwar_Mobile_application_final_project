import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/routine/domain/repository/routine_repository.dart';

class MockRoutineRepository extends Mock implements IRoutineRepository {}
