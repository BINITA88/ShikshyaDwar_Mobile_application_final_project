import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/routine/domain/use%20_case/get_all_routine.dart';

class MockGetRoutineUsecase extends Mock implements GetAllRoutines {}
