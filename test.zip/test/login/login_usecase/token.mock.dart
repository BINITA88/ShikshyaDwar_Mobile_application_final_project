import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/app/shared_prefs/token_shared_prefs.dart';

class MockTokenSharedPrefs extends Mock implements TokenSharedPrefs {}
