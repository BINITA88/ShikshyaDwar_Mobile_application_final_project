import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/Notice/domain/repository/notice_repository.dart';

class MockNoticeRepository extends Mock implements INoticeRepository {}
