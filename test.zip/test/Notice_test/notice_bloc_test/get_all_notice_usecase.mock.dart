import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/notice/domain/use%20_case/get_all_notice_usecase.dart';

class MockGetAllNoticeUseCase extends Mock implements GetAllNoticeUsecase {}
