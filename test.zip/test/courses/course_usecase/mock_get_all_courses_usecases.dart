import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/use_case/getAll_course_usecase.dart';

class MockGetAllCoursesUseCase extends Mock implements GetAllCourseUsecase {}
