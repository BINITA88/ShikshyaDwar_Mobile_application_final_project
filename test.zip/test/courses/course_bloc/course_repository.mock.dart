import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/repository/course_repository.dart';

class MockCourseRepository extends Mock implements ICourseRepository {}
