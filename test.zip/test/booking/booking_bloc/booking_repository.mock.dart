import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/booking/domain/repository/booking_repository.dart';

class MockBookingRepository extends Mock implements IBookingRepository {}
