import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/booking/domain/use_case/create_booking_usecase.dart';

class MockCreateBookingUsecase extends Mock implements CreateBookingUsecase {}
