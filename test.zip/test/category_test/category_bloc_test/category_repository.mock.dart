import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/category/domain/repository/category_repository.dart';

class MockCategoryRepository extends Mock implements ICategoryRepository {}
