import 'package:mocktail/mocktail.dart';
import 'package:shikshyadwar_mobile_application_project/features/auth/domain/repository/auth_repository.dart';

class MockAuthRepository extends Mock implements IAuthRepository {}
