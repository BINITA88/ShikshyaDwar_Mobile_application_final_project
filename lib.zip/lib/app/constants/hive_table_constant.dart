class HiveTableConstant {
  HiveTableConstant._();

  static const int studentTableId = 0;
  static const String studentBox = 'studentBox';

  static const int batchTableId = 1;
  static const String batchBox = 'batchBox';

  static const int courseTableId = 2;
  static const String courseBox = 'courseBox';

  static const int categoryTableId = 3;
  static const String categoryBox = 'categoryBox';
}

// hive ma sadhai id dina parcha 3 table made student,batch,coursebox
