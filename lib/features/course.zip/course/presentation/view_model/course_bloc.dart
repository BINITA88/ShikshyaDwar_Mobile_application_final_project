import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/entity/course_entity.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/use_case/getAll_course_usecase.dart';

part 'course_event.dart';
part 'course_state.dart';

class CourseBloc extends Bloc<CourseEvent, CourseState> {
  final GetAllCourseUsecase getAllCourseUsecase;

  CourseBloc({required this.getAllCourseUsecase}) : super(CourseState.initial()) {
    on<LoadCoursesEvent>(_onLoadCourses);
  }

  Future<void> _onLoadCourses(
      LoadCoursesEvent event, Emitter<CourseState> emit) async {
    emit(CourseState(isLoading: true, courses: state.courses, isSuccess: false, ));

    final result = await getAllCourseUsecase();

    result.fold(
      (failure) => emit(CourseState(isLoading: false, courses: state.courses, isSuccess: false,)),
      (courses) => emit(CourseState(
        isLoading: false,
        courses: courses,
        isSuccess: true,
      )),
    );
  }
}