import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/entity/course_entity.dart';

part 'course_api_model.g.dart';

@JsonSerializable()
class CourseApiModel extends Equatable {
  @JsonKey(name: '_id')
  final String courseId;

  @JsonKey(name: 'product_name')
  final String courseName;

  @JsonKey(name: 'product_price')
  final double coursePrice;

  final String instructor;

  @JsonKey(name: 'product_image')
  final String courseImage;

  final String duration;

  final String category;

  @JsonKey(name: 'product_description')
  final String courseDescription;

  CourseApiModel({
    required this.courseId,
    required this.courseName,
    required this.coursePrice,
    required this.instructor,
    required this.courseImage,
    required this.duration,
    required this.category,
    required this.courseDescription,
  });

  // Factory method to create a CourseApiModel from JSON
  factory CourseApiModel.fromJson(Map<String, dynamic> json) =>
      _$CourseApiModelFromJson(json);

  // Method to convert CourseApiModel to CourseEntity
  CourseEntity toEntity() {
    return CourseEntity(
      courseId: courseId,
      courseName: courseName,
      coursePrice: coursePrice,
      instructor: instructor,
      courseImage: courseImage,
      duration: duration,
      category: category,
      courseDescription: courseDescription,
    );
  }

  // Method to convert CourseApiModel to JSON
  Map<String, dynamic> toJson() => _$CourseApiModelToJson(this);

  @override
  List<Object?> get props => [
        courseId,
        courseName,
        coursePrice,
        instructor,
        courseImage,
        duration,
        category,
        courseDescription,
      ];
}
