import 'package:dartz/dartz.dart';
import 'package:shikshyadwar_mobile_application_project/core/error/failure.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/data/data_source/remote_datasource/Course_remote_datasource.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/entity/course_entity.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/repository/course_repository.dart';

class CourseRemoteRepository implements ICourseRepository {
  final CourseRemoteDatasource _courseRemoteDatasource;

  CourseRemoteRepository(this._courseRemoteDatasource);

  @override
  Future<Either<Failure, List<CourseEntity>>> getAllCourses() async {
    try {
      final courses = await _courseRemoteDatasource.getAllCourses();
      return Right(courses); // Returning the list of courses
    } catch (e) {
      return Left(ApiFailure(message: e.toString()));
    }
  }
}
