import 'package:dio/dio.dart';
import 'package:shikshyadwar_mobile_application_project/app/constants/api_endpoints.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/data/model/course_api_model.dart';
import 'package:shikshyadwar_mobile_application_project/features/course/domain/entity/course_entity.dart';

class CourseRemoteDatasource {
  final Dio _dio;

  CourseRemoteDatasource(this._dio);

  /// Gets all courses
  Future<List<CourseEntity>> getAllCourses() async {
    try {
      var response = await _dio.get(ApiEndpoints.getAllCourses);
      if (response.statusCode == 200) {
        var data = response.data as List<dynamic>;
        return data
            .map((course) => CourseApiModel.fromJson(course).toEntity())
            .toList();
      } else {
        throw Exception(response.statusMessage);
      }
    } on DioException catch (e) {
      throw Exception(e.message);
    } catch (e) {
      throw Exception(e.toString());
    }
  }
}
